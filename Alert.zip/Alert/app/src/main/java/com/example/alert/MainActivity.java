package com.example.alert;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.DialogInterface ;
import android.widget.Toast ;
import android.widget.Button ;
import android.view.View;
import android.app.AlertDialog ;



public class MainActivity extends AppCompatActivity {
    Button clsebtn ;
    AlertDialog.Builder builder ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        clsebtn = (Button) findViewById(R.id.btn) ;
        builder = new AlertDialog.Builder(this) ;

        clsebtn.setOnClickListener( new View.OnClickListener() {
            @Override

        public void onClick(View v) {

              // builder.setTitle(R.string.dialog_title);

                builder.setMessage("Do you want to close this app ?").setCancelable(false)
                .setPositiveButton("Yes ", new DialogInterface.OnClickListener() {
                     @Override
                     public void onClick(DialogInterface dialog, int id) {
                         finish();
                         Toast.makeText(getApplicationContext(),"Do you want close this app... ", Toast.LENGTH_SHORT).show();

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                                Toast.makeText(getApplicationContext(),"Do you  want  continue", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                            public void onClick(DialogInterface dialogInterface, int id) {
                            Toast.makeText(getApplicationContext(),"Do  yOU WANT to cancel", Toast.LENGTH_SHORT).show();

                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder.create();
                alert.setTitle("AlertDialog");
                alert.show();
            }
            });
        }
}